create database EzeeSolutions;
use EzeeSolutions;

CREATE TABLE EmployeeDetails (
    EmployeeID INT PRIMARY KEY,       -- Unique ID for each employee
    Name VARCHAR(100) NOT NULL,       -- Name of the employee
    Role VARCHAR(50) NOT NULL,        -- Role/Designation
    Team INT NOT NULL                 -- Team number
);
INSERT INTO EmployeeDetails (EmployeeID, Name, Role, Team) VALUES
(10245789, 'Riya Sharma', 'Senior Developer', 15),
(10234123, 'Aryan Patel', 'Junior Developer', 10),
(10298765, 'Neha Verma', 'QA Engineer', 12),
(10256324, 'Vikram Joshi', 'Project Manager', 20),
(10247612, 'Priya Singh', 'Backend Developer', 18),
(10256378, 'Arjun Kumar', 'Frontend Developer', 5),
(10245893, 'Simran Kaur', 'UX Designer', 8),
(10278145, 'Rahul Mehta', 'Data Analyst', 22),
(10236589, 'Karan Thakur', 'Software Engineer', 14),
(10249023, 'Meera Desai', 'Scrum Master', 11);

select * from EmployeeDetails;

CREATE TABLE trainings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    training_name VARCHAR(255) NOT NULL,
    trainer_name VARCHAR(255) NOT NULL,
    duration VARCHAR(50) NOT NULL,
    capacity INT NOT NULL
);
INSERT INTO trainings (training_name, trainer_name, duration, capacity)
VALUES 
  ('Advanced Drug Formulation', 'Dr. John Doe', '3 Days', 30),
  ('Pharmacology Basics', 'Dr. Jane Smith', '2 Days', 25),
  ('Quality Assurance Practices', 'Dr. Emily Clark', '4 Days', 40),
  ('Good Manufacturing Practices', 'Dr. Michael Davis', '5 Days', 35),
  ('Clinical Trial Management', 'Dr. Sarah Lee', '2 Days', 20),
  ('Regulatory Affairs and Compliance', 'Dr. Robert Brown', '3 Days', 15),
  ('Pharmaceutical Quality Control', 'Dr. William Taylor', '4 Days', 45),
  ('Biotechnology in Pharmaceuticals', 'Dr. Anna Miller', '5 Days', 50),
  ('Pharmaceutical Manufacturing Techniques', 'Dr. James Wilson', '3 Days', 30),
  ('Drug Regulatory and Patent Laws', 'Dr. Patricia Harris', '4 Days', 40),
  ('Medical Devices and Drug Interactions', 'Dr. Brian Clark', '2 Days', 35),
  ('Pharmacogenomics in Drug Development', 'Dr. Maria Martinez', '3 Days', 25),
  ('Pharmaceutical Industry Overview', 'Dr. Daniel Anderson', '2 Days', 30),
  ('Drug Safety and Risk Management', 'Dr. Lisa Thomas', '4 Days', 20),
  ('Pharmaceutical Marketing Strategies', 'Dr. David Robinson', '3 Days', 30),
  ('Pharmacovigilance and Drug Monitoring', 'Dr. Jessica White', '3 Days', 40),
  ('Pharmaceutical Chemistry Techniques', 'Dr. Steven Lee', '5 Days', 30),
  ('Pharmaceutical Project Management', 'Dr. Michael Brown', '4 Days', 45),
  ('Advanced Clinical Pharmacology', 'Dr. John Davis', '2 Days', 30),
  ('Pharmaceutical Research and Development', 'Dr. Susan Clark', '3 Days', 40);

select * from trainings;
DROP table TRAININGS;
drop table trainerdetails;
CREATE TABLE trainerdetails (
  TrainerID INT AUTO_INCREMENT PRIMARY KEY,
  TrainerName VARCHAR(100) NOT NULL,
  Designation VARCHAR(100) NOT NULL,
  Department VARCHAR(100) NOT NULL
);
INSERT INTO trainerdetails (TrainerName, Designation, Department) VALUES
('John Doe', 'Senior Trainer', 'Biochemistry'),
('Jane Smith', 'Trainer', 'Physics'),
('Mark Johnson', 'Lead Instructor', 'Mathematics'),
('Lucy Brown', 'Trainer', 'Biochemistry'),
('Chris Davis', 'Trainer', 'Chemistry'),
('Natalie White', 'Senior Trainer', 'Biology'),
('David Green', 'Lead Trainer', 'Physics'),
('Olivia Taylor', 'Trainer', 'Mathematics'),
('James Anderson', 'Lead Instructor', 'Chemistry'),
('Sarah Lee', 'Trainer', 'Biology'),
('Michael Wilson', 'Senior Trainer', 'Chemistry'),
('Emma Harris', 'Trainer', 'Physics'),
('Daniel Martin', 'Trainer', 'Mathematics'),
('Sophia Clark', 'Lead Instructor', 'Biochemistry'),
('Alexander Lewis', 'Trainer', 'Biology'),
('Mia Walker', 'Senior Trainer', 'Physics'),
('Benjamin Hall', 'Lead Instructor', 'Chemistry'),
('Isabella Allen', 'Trainer', 'Biology'),
('Liam Young', 'Lead Trainer', 'Biochemistry'),
('Ava King', 'Trainer', 'Physics');


drop table sop;
CREATE TABLE SOP (
    SOP_ID INT AUTO_INCREMENT PRIMARY KEY,
    SOP_Number VARCHAR(50) NOT NULL,
    SOP_Title VARCHAR(255) NOT NULL,
    Version_No VARCHAR(20) NOT NULL
);
INSERT INTO SOP (SOP_Number, SOP_Title, Version_No)
VALUES
    ('SOP001', 'Safety Procedures', '1.0'),
    ('SOP002', 'Machine Maintenance', '2.1'),
    ('SOP003', 'Chemical Handling Guidelines', '3.0'),
    ('SOP004', 'Emergency Evacuation Plan', '1.5'),
    ('SOP005', 'Quality Assurance Process', '4.2');


CREATE TABLE training_details (
  id INT AUTO_INCREMENT PRIMARY KEY,
  DocumentNumber VARCHAR(255) NOT NULL,
  RevisionNumber VARCHAR(255) NOT NULL,
  TrainerID INT NOT NULL,
  TrainerName VARCHAR(255) NOT NULL,
  TrainingDate DATE NOT NULL,
  TrainingLocation VARCHAR(255),
  TrainingDuration VARCHAR(255),
  TrainingSummary TEXT,
  TrainingTopic VARCHAR(255),
  SelectedUsers JSON, -- Store array of selected users as JSON
  SelectedTraining JSON, -- Store selected training details as JSON
  Sop JSON -- Store SOP details as JSON
);

select * from training_details;