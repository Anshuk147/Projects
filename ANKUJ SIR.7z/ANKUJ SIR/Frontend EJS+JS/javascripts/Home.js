//time logic
const starttime = document.getElementById("startTime");
const endtime = document.getElementById("endTime");
const span1 = document.getElementById("span1");
function calculateDuration() {
  // Parse the start and end times
  const start = starttime.value;
  const end = endtime.value;

  if (start && end) {
    // Convert the time strings into Date objects
    const startDate = new Date(`1970-01-01T${start}:00`);
    const endDate = new Date(`1970-01-01T${end}:00`);

    // Calculate the difference in milliseconds
    let duration = endDate - startDate;

    if (duration < 0) {
      // If the end time is earlier than the start time, adjust for the next day
      duration += 24 * 60 * 60 * 1000;
    }

    // Convert milliseconds to hours and minutes
    const hours = Math.floor(duration / (1000 * 60 * 60));
    const minutes = Math.floor((duration % (1000 * 60 * 60)) / (1000 * 60));

    // Display the duration in the span
    span1.textContent = `${hours} Hr${hours !== 1 ? "s" : ""} & ${minutes} Min${
      minutes !== 1 ? "s" : ""
    }`;
  } else {
    span1.textContent = "N/A";
  }
}
starttime.addEventListener("change", calculateDuration);
endtime.addEventListener("change", calculateDuration);

//Modal 1 Logics Start here
const modal1btn = $("#modal1button");
const ExistingTrainerForm = $("#ExistingTrainerForm");

modal1btn.on("click", function () {
  $.ajax({
    url: "http://localhost:4000/users/trainees", // Replace with your actual API endpoint
    method: "GET",
    dataType: "json",
    success: function (data) {
      console.log(data);

      // Clear previous content before adding new data
      ExistingTrainerForm.empty();

      // Iterate over the fetched data and create radio buttons for each item
      data.forEach(function (trainer, index) {
        const divsnippet = `
          <div class="form-group">
            <div class="form-check">
              <input class="form-check-input" type="radio" name="Modal1radios" id="Modal1${index}" value="Modal1option${index}" data-id="${trainer.Trainee_ID}" data-name="${trainer.Trainee_Name}">
              <label class="form-check-label p-2 bg-light text-dark rounded d-block" for="Modal1${index}">
                <strong>ID:</strong> ${trainer.Trainee_ID} &nbsp; | &nbsp; 
                <strong>Name:</strong> ${trainer.Trainee_Name} &nbsp; | &nbsp; 
                <strong>Department:</strong> ${trainer.Department} &nbsp; | &nbsp; 
                <strong>Designation:</strong> ${trainer.Designation}
              </label>
            </div>
          </div>
        `;

        // Append the new div to the form container
        ExistingTrainerForm.append(divsnippet);
      });

      // Add event listeners to the radio buttons
      $('input[name="Modal1radios"]').on("change", function () {
        if ($(this).is(":checked")) {
          const traineeID = $(this).data("id");
          const traineeName = $(this).data("name");

          // Assuming you have input fields with IDs for name and code
          $("#Trainername").val(traineeName); // Set value for Trainername field
          $("#trainercode").val(traineeID); // Set value for trainercode field
        }
      });
    },
    error: function (err) {
      console.error(err);
    },
  });
});
//Modal 1 Logics ENDS here
// training type button starts here
const trainings = [
  "Good Manufacturing Practice (GMP)",
  "Good Laboratory Practice (GLP)",
  "Good Clinical Practice (GCP)",
  "Compliance and Regulatory",
  "Standard Operating Procedures (SOP)",
  "Health and Safety",
  "Data Integrity",
  "Quality Assurance and Quality Control (QA/QC)",
  "Technical/Job-Specific",
  "Soft Skills and Leadership",
  "Environmental and Waste Management",
  "Ethics and Code of Conduct",
];
const $TrainingTypeForm = $("#TrainingTypeForm");
const $TrainingTypeBtn = $("#TrainingTypeBtn");
let selectedTrainingType = null;

$TrainingTypeBtn.on("click", function () {
  $TrainingTypeForm.empty();

  $.each(trainings, function (index, item) {

    const $div = $("<div>").addClass("form-inline mt-2");

 
    const $input = $("<input>")
      .addClass("form-check-input")
      .attr("type", "radio")
      .attr("name", "TrainingTyperadios")
      .attr("id", `TrainingType${index}`)
      .attr("value", `TrainingTypeoption${index}`)
      .data("id", item)
      .data("name", item);

    const $label = $("<label>")
      .addClass("form-check-label p-2 bg-light text-dark rounded d-block")
      .attr("for", `TrainingType${index}`)
      .html(`<strong>${item}</strong> &nbsp;`);


    $div.append($input).append($label);

    $TrainingTypeForm.append($div);
  });

  $TrainingTypeForm.find('input[name="TrainingTyperadios"]').on("change", function (event) {
    if ($(this).prop("checked")) {
      selectedTrainingType = $(this).data("name");
      console.log("training Name =", selectedTrainingType);
    }
  });
});
// training type button logic ends here
const SOPForm = $("#SOP"); 
const SopBtn = $("#SopBtn"); 
let Sopname = undefined;

SopBtn.on("click", () => {

  $.ajax({
    url: "http://localhost:4000/users/sop", 
    method: "GET", 
    success: (data) => {
      console.log("Fetched Data:", data);

      const sopItems = Array.isArray(data) ? data : data.data;

      if (!Array.isArray(sopItems)) {
        throw new Error("SOP data is not an array"); 
      }

      SOPForm.empty();

      sopItems.forEach((item, index) => {
        const snippet = `
          <div class="form-inline mt-2">
            <input class="form-check-input" type="radio" name="TrainingTyperadios" id="SOP${index}" value="SOPTypeoption${index}" data-id="${item.SOP_Number}" data-name="${item.SOP_Title}" data-version="${item.Version_No}">
            <label class="form-check-label p-2 bg-light text-dark rounded d-block" for="SOP${index}"> 
              <strong>${item.SOP_Title}</strong> &nbsp;<span class="text-muted">(${item.Version_No})</span>
            </label>
          </div>`;
        
        SOPForm.append(snippet); 
      });

 
      $('input[name="TrainingTyperadios"]').on("change", (event) => {
        if ($(event.target).prop("checked")) {
          Sopname = $(event.target).data("name"); 
          console.log("Selected SOP:", {
            id: $(event.target).data("id"),
            name: Sopname,
            version: $(event.target).data("version"),
          });
        }
      });
    },
    error: (error) => {
      console.error("Error fetching SOP data:", error);
      SOPForm.html("<p class='text-danger'>Failed to load SOP data. Please try again later.</p>");
    }
  });
});
//breakpoint
let SelectedUserArray = [];
$(document).ready(function () { 
  $.ajax({
    url: "http://localhost:4000/users/details",
    method: "GET",
    success: function (data) {
      const UserData = data.data;

      UserData.forEach((item) => {
        const snippet = `
          <tr class="text-left">
            <th scope="row" class="text-center">${item.Trainer_ID}</th>
            <td>${item.Trainer_Name}</td>
            <td>${item.Department}</td>
            <td>${item.Designation}</td>
            <td class="text-center">
              <input
                type="checkbox"
                name="ExistinguserCheckBOX"
                data-trainerid="${item.Trainer_ID}"          
                data-trainername="${item.Trainer_Name}"      
                data-department="${item.Department}"         
                data-designation="${item.Designation}"       
                aria-label="Checkbox for following text input"
              />
            </td>
          </tr>`;
        $("#ExistingUserTablebody").append(snippet);
      });

      $("#ExistingUserTable").DataTable();
    },
    error: function (error) {
      console.log(error);
    }
  });


  function updateSelectedUserTable() {
    if ($.fn.DataTable.isDataTable("#SelectedUserTable")) {
      $("#SelectedUserTable").DataTable().clear().destroy();
    }

    $("#SelectedUserTableBody").empty();

    SelectedUserArray.forEach((item) => {
      const row = `
        <tr class="text-left">
          <th scope="row" class="text-center">${item.id}</th>
          <td>${item.name}</td>
          <td>${item.Department}</td>
          <td>${item.Designation}</td>
          <td class="text-center">
            <input
              type="checkbox"
              name="SelecteduserRadio"
              data-trainerid="${item.id}"          
              data-trainername="${item.name}"      
              data-department="${item.Department}"         
              data-designation="${item.Designation}"       
              aria-label="Checkbox for following text input"
            />
          </td>
        </tr>`;
      $("#SelectedUserTableBody").append(row);
    });

    $("#SelectedUserTable").DataTable({
      paging: true,
      searching: true,
      ordering: true,
      info: true,
      responsive: true
    });
  }

  $("#greaterthanBtn").on("click", function () {
    $('input[name="ExistinguserCheckBOX"]:checked').each(function () {
      const data = {
        id: $(this).data("trainerid"),
        name: $(this).data("trainername"),
        Department: $(this).data("department"),
        Designation: $(this).data("designation")
      };

 
      if (!SelectedUserArray.some((user) => user.id === data.id)) {
        SelectedUserArray.push(data);
      }
    });

    console.log(SelectedUserArray); 
    updateSelectedUserTable();
  });


  $("#LgtBtn").on("click", function () {
    const dataTable = $("#SelectedUserTable").DataTable();

    $('input[name="SelecteduserRadio"]:checked').each(function () {
      const userId = $(this).data("trainerid");

      
      SelectedUserArray = SelectedUserArray.filter((user) => user.id !== userId);

  
      const row = $(this).closest("tr"); 
      dataTable.row(row).remove().draw(); 
    });

    console.log("Selected rows removed from SelectedUserTable.");
    console.log("Updated SelectedUserArray:", SelectedUserArray);
  });
});

// update the data into the table
function createTrainingJson() {
  if (SelectedUserArray.length === 0) {
    alert("Please select at least one user.");
    return;   
  }

  // Continue with the rest of the function if users are selected
  const trainerName = document.getElementById("Trainername").value;
  const trainerCode = document.getElementById("trainercode").value;
  const trainingDate = document.getElementById("TrainingDate").value;
  const startTime = document.getElementById("startTime").value;
  const endTime = document.getElementById("endTime").value;
  const trainingDuration = document.getElementById("span1").textContent; // Duration from span1
  const documentNumber = document.getElementById("DocumentNumber").value;
  const trainingTopic = selectedTrainingType; // This should be from your selected training topic
  const revisionNumber = document.getElementById("Revisionnumber").value;
  const sopName = Sopname; // Assuming SOP name is stored in this field
  const summary = document.getElementById("Summary").value; // Assuming summary is in this field
  const location = document.getElementById("traininglocation").value; // Assuming location is in this field

  // Create the JSON object
  const trainingData = {
    "Trainer Name": trainerName,
    "Trainer Code": trainerCode,
    "Training Date": trainingDate,
    "Start Time": startTime,
    "End Time": endTime,
    "Training Duration": trainingDuration,
    "Document Number": documentNumber,
    "Training topic": trainingTopic,
    "Revision Number": revisionNumber,
    "SOP Name": sopName,
    "Summary": summary,
    "Location": location,
    "Selected User": SelectedUserArray.map((user) => ({
      Trainer_ID: user.id,
      Trainer_Name: user.name,
    })),
  };

  console.log("Training Data:", JSON.stringify(trainingData));

  return trainingData;
}

const ScheduleBtn = document.getElementById("ScheduleBtn");


ScheduleBtn.addEventListener("click", () => {
  const trainingData = createTrainingJson();

  if (!trainingData) return;


  const xhr = new XMLHttpRequest();


  xhr.open('POST', 'http://localhost:4000/users/api/saveTrainingData', true);
  

  xhr.setRequestHeader('Content-Type', 'application/json');


  xhr.onload = function() {
    if (xhr.status >= 200 && xhr.status < 300) {
      const data = JSON.parse(xhr.responseText);
      if (data.message === 'Training data saved successfully') {
        alert('Training data saved successfully!');
      } else {
        alert('Failed to save training data.');
      }
      console.log(data);
    } else {
      console.error('Error in response:', xhr.statusText);
      alert('There was an error saving the training data.');
    }
  };

  
  xhr.onerror = function() {
    console.error('Request failed');
    alert('There was an error with the request.');
  };

  xhr.send(JSON.stringify(trainingData));
});


