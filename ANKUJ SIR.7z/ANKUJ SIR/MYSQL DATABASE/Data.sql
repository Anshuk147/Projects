create database ezeesolutions;
use ezeesolutions;
CREATE TABLE existing_trainees (
    Trainee_ID INT AUTO_INCREMENT PRIMARY KEY,
    Trainee_Name VARCHAR(100),
    Department VARCHAR(100),
    Designation VARCHAR(100)
);
INSERT INTO existing_trainees (Trainee_Name, Department, Designation)
VALUES
    ('Alice Johnson', 'Human Resources', 'Manager'),
    ('Bob Smith', 'Information Technology', 'Developer'),
    ('Charlie Brown', 'Sales', 'Executive'),
    ('David Miller', 'Marketing', 'Analyst'),
    ('Eve Adams', 'Finance', 'Accountant');
CREATE TABLE sop (
    SOP_Number INT AUTO_INCREMENT PRIMARY KEY,
    SOP_Title VARCHAR(255) NOT NULL,
    Version_No VARCHAR(50) NOT NULL
);
INSERT INTO sop (SOP_Title, Version_No) VALUES
('SOP for Inventory Management', 'v1.0'),
('SOP for Employee Onboarding', 'v1.1'),
('SOP for Sales Reporting', 'v2.0'),
('SOP for Customer Support', 'v3.0'),
('SOP for Data Security', 'v1.2'),
('SOP for Financial Audits', 'v2.5'),
('SOP for IT Maintenance', 'v1.4'),
('SOP for Marketing Strategies', 'v2.1'),
('SOP for Quality Assurance', 'v3.2'),
('SOP for Product Launches', 'v4.0');
CREATE TABLE trainer_details (
  Trainer_ID INT AUTO_INCREMENT PRIMARY KEY,
  Trainer_Name VARCHAR(255) NOT NULL,
  Department VARCHAR(255) NOT NULL,
  Designation VARCHAR(255) NOT NULL
);
INSERT INTO trainer_details (Trainer_Name, Department, Designation)
VALUES 
  ('John Doe', 'IT', 'Senior Trainer'),
  ('Jane Smith', 'HR', 'HR Manager'),
  ('Michael Brown', 'Finance', 'Finance Lead'),
  ('Emily White', 'IT', 'Junior Trainer');

CREATE TABLE training (
  id INT AUTO_INCREMENT PRIMARY KEY,
  trainer_name VARCHAR(255) NOT NULL,
  trainer_code VARCHAR(255) NOT NULL,
  training_date DATE NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  training_duration VARCHAR(255) NOT NULL,
  document_number VARCHAR(255) NOT NULL,
  training_topic VARCHAR(255) NOT NULL,
  revision_number VARCHAR(255) NOT NULL,
  sop_name VARCHAR(255) NOT NULL,
  summary TEXT NOT NULL,
  location VARCHAR(255) NOT NULL,
  selected_users JSON NOT NULL
);

CREATE TABLE TrainingData (
  id INT AUTO_INCREMENT PRIMARY KEY,
  training_data JSON NOT NULL
);
select * from TrainingData;
