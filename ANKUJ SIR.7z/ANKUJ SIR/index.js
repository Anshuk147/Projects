var express = require('express');
var router = express.Router();
var connection = require("../DB/Dbconfig")
const { body, validationResult } = require("express-validator");
/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index');
});

router.get('/Preview', function(req, res, next) {
  res.render("Preview");
});
router.get('/TrainingRecording', function(req, res, next) {
  res.render("TrainingApp");
});

router.post('/saveTrainee', async (req, res) => {
  try {
    const { TraineeId, TraineeName, Designation, Department, Email, Contact } = req.body;

    // Check if all fields are present
    if (!TraineeId || !TraineeName || !Designation || !Department || !Email || !Contact) {
      return res.status(400).send('Missing required fields');
    }

    const query = `
      INSERT INTO trainees (TraineeId, TraineeName, Designation, Department, Email, Contact)
      VALUES (?, ?, ?, ?, ?, ?)
    `;
    const values = [TraineeId, TraineeName, Designation, Department, Email, Contact];

    // Directly await the query execution
    await new Promise((resolve, reject) => {
      connection.query(query, values, (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });

    res.status(200).send('Data saved successfully');
  } catch (err) {
    console.error('Error saving trainee data:', err.message);
    res.status(500).send('Error saving data');
  }
});
router.get("/api/employees", (req, res) => {
  const query = "SELECT EmployeeID, Name, Role, Team FROM EmployeeDetails";
  connection.query(query, (err, results) => {
      if (err) {
          console.error("Error fetching data:", err);
          res.status(500).send("Internal Server Error");
      } else {
          res.status(200).json(results);
      }
  });
});
router.get('/api/trainings', (req, res) => {
  const sqlquery = 'SELECT * FROM trainings';

  connection.query(sqlquery, (err, results) => {
    if (err) {
      return res.status(500).send({ message: 'Error fetching data' });
    }
    res.json(results);
  });
});
router.get('/api/trainers', (req, res) => {
  const query = 'SELECT * FROM TrainerDetails';
  connection.query(query, (error, results) => {
      if (error) {
          console.error('Error fetching trainer data:', error);
          res.status(500).json({ error: 'Failed to fetch trainer data' });
      } else {
          res.status(200).json(results);
      }
  });
});
router.get('/api/sops', (req, res) => {
  const query = 'SELECT * FROM SOP';

  connection.query(query, (err, results) => {
    if (err) {
      console.error('Error fetching SOP data:', err.message);
      return res.status(500).json({ error: 'Failed to fetch SOP data' });
    }

    res.status(200).json(results);
  });
});

router.post(
  "/api/schedule-training",
  [
    // Basic field validations
    body("TrainingDate")
      .notEmpty()
      .withMessage("Training date is required"),
    body("TrainerName").notEmpty().withMessage("Trainer name is required"),
    body("TrainerID").isInt().withMessage("Trainer ID must be an integer"),
    body("TrainingLocation")
      .notEmpty()
      .withMessage("Training location is required"),
    body("RevisionNumber")
      .isInt({ min: 1 })
      .withMessage("Revision number must be a positive integer"),
    body("DocumentNumber")
      .notEmpty()
      .withMessage("Document number is required"),
    body("TrainingTopic").notEmpty().withMessage("Training topic is required"),
    body("TrainingSummary")
      .notEmpty()
      .withMessage("Training summary is required"),
    body("SelectedUsers")
      .isArray({ min: 1 })
      .withMessage("At least one user must be selected"),

    // Duration validation
    body("TrainingDuration")
      .notEmpty()
      .withMessage("Training duration is required"),

    // Custom validation for selectedTraining
    body("selectedTraining").custom((value) => {
      if (!value || typeof value !== "object" || Object.keys(value).length === 0) {
        throw new Error("Please select a training");
      }
      if (!value.training_id || !value.training_name) {
        throw new Error(
          "Selected training must include training_id and training_name"
        );
      }
      return true;
    }),

    // Custom validation for SOP
    body("Sop").custom((value) => {
      if (!value || typeof value !== "object" || Object.keys(value).length === 0) {
        throw new Error("SOP details are required");
      }
      if (!value.sop_id || !value.sop_number || !value.title) {
        throw new Error(
          "SOP must include sop_id, sop_number, and title"
        );
      }
      return true;
    }),
  ],
  async (req, res) => {
    try {
      // Extract validation errors
      const errors = validationResult(req);

      // If validation fails, send error messages
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      // Destructure the request body
      const {
        TrainerName,
        TrainerID,
        TrainingLocation,
        RevisionNumber,
        DocumentNumber,
        TrainingTopic,
        TrainingSummary,
        SelectedUsers,
        TrainingDuration,
        selectedTraining,
        Sop,
      } = req.body;

      // SQL query to insert the data into training_details table
      const query = `
        INSERT INTO training_details 
        (DocumentNumber, RevisionNumber, TrainerID, TrainerName, TrainingDate, TrainingLocation, 
        TrainingDuration, TrainingSummary, TrainingTopic, SelectedUsers, SelectedTraining, Sop)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;

      // Execute the query with the provided data
      const result = await connection.promise().query(query, [
        DocumentNumber,
        RevisionNumber,
        TrainerID,
        TrainerName,
        req.body.TrainingDate, // Assuming the TrainingDate is sent as a string in the request
        TrainingLocation,
        TrainingDuration,
        TrainingSummary,
        TrainingTopic,
        JSON.stringify(SelectedUsers), // Convert selected users to JSON
        JSON.stringify(selectedTraining), // Convert selected training to JSON
        JSON.stringify(Sop), // Convert SOP to JSON
      ]);

      // Respond with success message
      res.status(200).json({
        message: "Training successfully scheduled",
        data: {
          TrainerName,
          TrainerID,
          TrainingLocation,
          RevisionNumber,
          DocumentNumber,
          TrainingTopic,
          TrainingSummary,
          SelectedUsers,
          TrainingDuration,
          selectedTraining,
          Sop,
        },
      });
    } catch (error) {
      console.error("Error scheduling training:", error);

      // Respond with server error
      res.status(500).json({
        message: "An unexpected error occurred. Please try again later.",
        error: error.message,
      });
    }
  }
);


module.exports = router;
