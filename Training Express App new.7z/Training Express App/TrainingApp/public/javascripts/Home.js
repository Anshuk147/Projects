//time logic
const starttime = document.getElementById("startTime");
const endtime = document.getElementById("endTime");
const span1 = document.getElementById("span1");
function calculateDuration() {
  // Parse the start and end times
  const start = starttime.value;
  const end = endtime.value;

  if (start && end) {
    // Convert the time strings into Date objects
    const startDate = new Date(`1970-01-01T${start}:00`);
    const endDate = new Date(`1970-01-01T${end}:00`);

    // Calculate the difference in milliseconds
    let duration = endDate - startDate;

    if (duration < 0) {
      // If the end time is earlier than the start time, adjust for the next day
      duration += 24 * 60 * 60 * 1000;
    }

    // Convert milliseconds to hours and minutes
    const hours = Math.floor(duration / (1000 * 60 * 60));
    const minutes = Math.floor((duration % (1000 * 60 * 60)) / (1000 * 60));

    // Display the duration in the span
    span1.textContent = `${hours} Hr${hours !== 1 ? "s" : ""} & ${minutes} Min${
      minutes !== 1 ? "s" : ""
    }`;
  } else {
    span1.textContent = "N/A";
  }
}

// Add event listeners to recalculate when times change
starttime.addEventListener("change", calculateDuration);
endtime.addEventListener("change", calculateDuration);

//time logic

//Modal 1 Logics
const modal1btn = document.getElementById("modal1button");
const ExistingTrainerForm = document.getElementById("ExistingTrainerForm");

modal1btn.addEventListener("click", () => {
  fetch("http://localhost:4000/users/trainees")
    .then((response) => response.json())
    .then((data) => {
      // Clear previous content before adding new data
      ExistingTrainerForm.innerHTML = "";

      // Iterate over the fetched data and create radio buttons for each item
      data.forEach((trainer, index) => {
        const divsnippet = `
          <div class="form-group">
            <div class="form-check">
              <input class="form-check-input" type="radio" name="Modal1radios" id="Modal1${index}" value="Modal1option${index}" data-id="${trainer.Trainee_ID}" data-name="${trainer.Trainee_Name}">
            <label class="form-check-label p-2 bg-light text-dark rounded d-block" for="Modal1${index}">
              <strong>ID:</strong> ${trainer.Trainee_ID} &nbsp; | &nbsp; 
              <strong>Name:</strong> ${trainer.Trainee_Name} &nbsp; | &nbsp; 
              <strong>Department:</strong> ${trainer.Department} &nbsp; | &nbsp; 
              <strong>Designation:</strong> ${trainer.Designation}
            </label>
            </div>
          </div>
        `;

        // Append the new div to the form container
        ExistingTrainerForm.innerHTML += divsnippet;
      });

      // Add event listeners to the radio buttons
      document
        .querySelectorAll('input[name="Modal1radios"]')
        .forEach((radio) => {
          radio.addEventListener("change", (event) => {
            if (event.target.checked) {
              const selectedTrainer = event.target;
              const traineeID = selectedTrainer.getAttribute("data-id");
              const traineeName = selectedTrainer.getAttribute("data-name");

              // Assuming you have input fields with IDs for name and code
              document.getElementById("Trainername").value = traineeName; // Corrected: Set value for Trainername field
              document.getElementById("trainercode").value = traineeID; // Corrected: Set value for trainercode field
            }
          });
        });
    })
    .catch((err) => {
      console.log(err);
    });
});

//Training Type Btn Logic
const trainings = [
  "Good Manufacturing Practice (GMP)",
  "Good Laboratory Practice (GLP)",
  "Good Clinical Practice (GCP)",
  "Compliance and Regulatory",
  "Standard Operating Procedures (SOP)",
  "Health and Safety",
  "Data Integrity",
  "Quality Assurance and Quality Control (QA/QC)",
  "Technical/Job-Specific",
  "Soft Skills and Leadership",
  "Environmental and Waste Management",
  "Ethics and Code of Conduct",
];
//Training Type logic
const TrainingTypeForm = document.getElementById("TrainingTypeForm");
const TrainingTypeBtn = document.getElementById("TrainingTypeBtn");
let selectedTrainingType = null;

TrainingTypeBtn.addEventListener("click", () => {
  // Clear the form first (optional, if you want to reset every time the button is clicked)
  TrainingTypeForm.innerHTML = "";

  // Assuming `trainings` is an array available in the scope
  trainings.forEach((item, index) => {
    const div = document.createElement("div");
    div.classList.add("form-inline", "mt-2");

    const input = document.createElement("input");
    input.classList.add("form-check-input");
    input.type = "radio";
    input.name = "TrainingTyperadios";
    input.id = `TrainingType${index}`;
    input.value = `TrainingTypeoption${index}`;
    input.setAttribute("data-id", item);
    input.setAttribute("data-name", item);

    const label = document.createElement("label");
    label.classList.add(
      "form-check-label",
      "p-2",
      "bg-light",
      "text-dark",
      "rounded",
      "d-block"
    );
    label.setAttribute("for", `TrainingType${index}`);
    label.innerHTML = `<strong>${item}</strong> &nbsp;`;

    // Append the input and label to the div
    div.appendChild(input);
    div.appendChild(label);

    // Append the div to the form
    TrainingTypeForm.appendChild(div);
  });

  // Add a single event listener for all radio buttons
  TrainingTypeForm.querySelectorAll('input[name="TrainingTyperadios"]').forEach(
    (item) => {
      item.addEventListener("change", (event) => {
        if (event.target.checked) {
          selectedTrainingType = event.target.getAttribute("data-name");
          console.log("training Name =", selectedTrainingType);
        }
      });
    }
  );
});

//SOP Logics
const SOPForm = document.getElementById("SOP");
const SopBtn = document.getElementById("SopBtn");
let Sopname = undefined;
SopBtn.addEventListener("click", async () => {
  try {
    const response = await fetch("http://localhost:4000/users/sop");
    const data = await response.json();

    console.log("Fetched Data:", data); // Log the data to check its structure

    // Assuming the actual SOP data is inside a property like `data.data`
    const sopItems = Array.isArray(data) ? data : data.data; // Adjust based on the structure

    if (!Array.isArray(sopItems)) {
      throw new Error("SOP data is not an array"); // Handle unexpected structure
    }

    // Clear previous content in SOPForm
    SOPForm.innerHTML = "";

    sopItems.forEach((item, index) => {
      const snippet = `<div class="form-inline mt-2">
        <input class="form-check-input" type="radio" name="TrainingTyperadios" id="SOP${index}" value="SOPTypeoption${index}" data-id="${item.SOP_Number}" data-name="${item.SOP_Title}" data-version="${item.Version_No}">
        <label class="form-check-label p-2 bg-light text-dark rounded d-block" for="SOP${index}"> 
          <strong>${item.SOP_Title}</strong> &nbsp;<span class="text-muted">(${item.Version_No})</span>
        </label>
      </div>`;
      SOPForm.innerHTML += snippet;
    });
    // Optional: Add event listeners to the new radio buttons if needed
    SOPForm.querySelectorAll('input[name="TrainingTyperadios"]').forEach(
      (radio) => {
        radio.addEventListener("change", (event) => {
          if (event.target.checked) {
            (Sopname = event.target.getAttribute("data-name")),
              console.log("Selected SOP:", {
                id: event.target.getAttribute("data-id"),
                name: event.target.getAttribute("data-name"),
                version: event.target.getAttribute("data-version"),
              });
          }
        });
      }
    );
  } catch (error) {
    console.error("Error fetching SOP data:", error);
    // Optionally, add a message to SOPForm indicating an error occurred
    SOPForm.innerHTML =
      "<p class='text-danger'>Failed to load SOP data. Please try again later.</p>";
  }
});
//Exising user table
const ExistingUserTablebody = document.getElementById("ExistingUserTablebody");
const ExistingUserTable = document.getElementById("ExistingUserTable");
const SelectedUserTable = document.getElementById("SelectedUserTable");
const Selectedusertablebody = document.getElementById("SelectedUserTableBody");

// Declare SelectedUserArray as a global variable
let SelectedUserArray = [];
document.addEventListener("DOMContentLoaded", () => {
  try {
    fetch("http://localhost:4000/users/details")
      .then((response) => response.json())
      .then((data) => {
        const UserData = data.data;

        UserData.forEach((item) => {
          const snippet = `<tr class="text-left">
            <th scope="row" class="text-center">${item.Trainer_ID}</th>
            <td>${item.Trainer_Name}</td>
            <td>${item.Department}</td>
            <td>${item.Designation}</td>
            <td class="text-center">
              <input
                type="checkbox"
                name="ExistinguserCheckBOX"
                data-trainerid="${item.Trainer_ID}"          
                data-trainername="${item.Trainer_Name}"      
                data-department="${item.Department}"         
                data-designation="${item.Designation}"       
                aria-label="Checkbox for following text input"
              />
            </td>
          </tr>`;
          ExistingUserTablebody.innerHTML += snippet;
        });

        $(ExistingUserTable).DataTable();
      });
  } catch (error) {
    console.log(error);
  }

  const updateSelectedUserTable = () => {
    if ($.fn.DataTable.isDataTable("#SelectedUserTable")) {
      $("#SelectedUserTable").DataTable().clear().destroy();
    }

    Selectedusertablebody.innerHTML = "";

    SelectedUserArray.forEach((item) => {
      const row = document.createElement("tr");
      row.classList.add("text-left");

      row.innerHTML = `
        <th scope="row" class="text-center">${item.id}</th>
        <td>${item.name}</td>
        <td>${item.Department}</td>
        <td>${item.Designation}</td>
        <td class="text-center">
          <input
            type="checkbox"
            name="SelecteduserRadio"
            data-trainerid="${item.id}"          
            data-trainername="${item.name}"      
            data-department="${item.Department}"         
            data-designation="${item.Designation}"       
            aria-label="Checkbox for following text input"
          />
        </td>
      `;

      Selectedusertablebody.appendChild(row);
    });

    $("#SelectedUserTable").DataTable({
      paging: true,
      searching: true,
      ordering: true,
      info: true,
      responsive: true,
    });
  };

  function handleLgtButtonClick() {
    const checkedBoxes = document.querySelectorAll(
      'input[name="ExistinguserCheckBOX"]:checked'
    );
    checkedBoxes.forEach((checkbox) => {
      const data = {
        id: checkbox.getAttribute("data-trainerid"),
        name: checkbox.getAttribute("data-trainername"),
        Department: checkbox.getAttribute("data-department"),
        Designation: checkbox.getAttribute("data-designation"),
      };

      // Check for duplicates based on id
      if (!SelectedUserArray.some((user) => user.id === data.id)) {
        SelectedUserArray.push(data);
      }
    });

    console.log(SelectedUserArray); // Check the array in the console
  }

  document.getElementById("greaterthanBtn").addEventListener("click", () => {
    handleLgtButtonClick();
    updateSelectedUserTable();
  });

  if (!$.fn.DataTable.isDataTable("#SelectedUserTable")) {
    $("#SelectedUserTable").DataTable({
      paging: true,
      searching: true,
      ordering: true,
      info: true,
      responsive: true,
    });
  }
});


// Function to update SelectedUserTable
// Main function for the 'LgtBtn' click event
document.addEventListener("DOMContentLoaded", () => {
  const LgtBtn = document.getElementById("LgtBtn");

  LgtBtn.addEventListener("click", () => {
    // Get reference to DataTable instance
    const dataTable = $("#SelectedUserTable").DataTable();

    const checkedItems = document.querySelectorAll(
      'input[name="SelecteduserRadio"]:checked'
    );

    checkedItems.forEach((checkbox) => {
      const userId = checkbox.getAttribute("data-trainerid");

      // Update SelectedUserArray by removing the user
      SelectedUserArray = SelectedUserArray.filter((user) => user.id !== userId);

      // Use DataTables API to remove the row
      const row = $(checkbox).closest("tr"); // Find the row element
      dataTable.row(row).remove().draw(); // Remove the row and redraw the table
    });

    console.log("Selected rows removed from SelectedUserTable.");
    console.log("Updated SelectedUserArray:", SelectedUserArray);
  });
});



// Record the details of the training
function createTrainingJson() {
  const trainerName = document.getElementById("Trainername").value;
  const trainerCode = document.getElementById("trainercode").value;
  const trainingDate = document.getElementById("TrainingDate").value;
  const startTime = document.getElementById("startTime").value;
  const endTime = document.getElementById("endTime").value;
  const trainingDuration = document.getElementById("span1").textContent; // Duration from span1
  const documentNumber = document.getElementById("DocumentNumber").value;
  const trainingTopic = selectedTrainingType; // This should be from your selected training topic
  const revisionNumber = document.getElementById("Revisionnumber").value;
  const sopName = Sopname; // Assuming SOP name is stored in this field
  const summary = document.getElementById("Summary").value; // Assuming summary is in this field
  const location = document.getElementById("traininglocation").value; // Assuming location is in this field

  // Create the JSON object
  const trainingData = {
    "Trainer Name": trainerName,
    "Trainer Code": trainerCode,
    "Training Date": trainingDate,
    "Start Time": startTime,
    "End Time": endTime,
    "Training Duration": trainingDuration,
    "Document Number": documentNumber,
    "Training topic": trainingTopic,
    "Revision Number": revisionNumber,
    "SOP Name": sopName,
    Summary: summary,
    Location: location,
    "Selected User": SelectedUserArray.map((user) => ({
      Trainer_ID: user.id,
      Trainer_Name: user.name,
    })),
  };
  console.log("Training Data:", JSON.stringify(trainingData));

  return trainingData;
}
const ScheduleBtn = document.getElementById("ScheduleBtn");
const apiUrl = "http://localhost:4000/users/api/saveTrainingData";

ScheduleBtn.addEventListener("click", () => {
  fetch(apiUrl, {
    method: 'POST',  // The HTTP method (POST for sending data)
    headers: {
      'Content-Type': 'application/json',  // Tell the server we're sending JSON
    },
    body: JSON.stringify(createTrainingJson),  // Convert the training data to a JSON string
  })
    .then(response => {
      // Check if the response status is OK (status code 200-299)
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response.json();  // Parse the JSON response
    })
    .then(data => {
      // Handle the successful response
      console.log('Success:', data);
      // Example: Show a success message or redirect the user
      alert('Training data saved successfully!');
    })
    .catch(error => {
      // Handle any errors that occurred during the request
      console.error('Error:', error);
      alert('Failed to save training data');
    });
});

