var express = require('express');
var router = express.Router();
const connection = require('../public/javascripts/Database');
/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

// GET API to fetch all existing trainees
router.get("/trainees", (req, res) => {
  connection.query("SELECT * FROM existing_trainees", (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.status(200).json(results);
  });
});
//GET API to fetch the sops
router.get("/sop", async (req, res) => {
  try {
    const [rows] = await connection.promise().query("SELECT * FROM sop");
    res.status(200).json({ message: "SOP Details", data: rows });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
//GET API to fetch the trainer_details
router.get("/details",async(req,res)=>{
  try {
    const[rows]=await connection.promise().query("select * from trainer_details");
    res.status(200).json({ message: "trainer Details", data: rows });
  } catch (error) {
    res.status(400).json({ error: err.message });
  }
})
//POST API TO PUSH THE DATA INTO THE DATABASE
const trainingData = {
  "Trainer Name": "2",
  "Trainer Code": "2",
  "Training Date": "2024-11-07",
  "Start Time": "08:00",
  "End Time": "10:58",
  "Training Duration": "2 Hrs & 58 Mins",
  "Document Number": "2",
  "Training topic": "Compliance and Regulatory",
  "Revision Number": "2",
  "SOP Name": "Quality Control Procedures",
  "Summary": "2",
  "Location": "2",
  "Selected User": [
    { "Trainer_ID": "1", "Trainer_Name": "David Brown" },
    { "Trainer_ID": "2", "Trainer_Name": "Emma Wilson" },
    { "Trainer_ID": "3", "Trainer_Name": "Frank Green" }
  ]
};

// API endpoint to store training data
router.post('/api/saveTrainingData', (req, res) => {
  // Directly using the provided training data
  const trainingDataJson = JSON.stringify(trainingData);

  // Insert the entire training data (as JSON) into the TrainingData table
  const trainingQuery = `INSERT INTO TrainingData (training_data) VALUES (?)`;

  connection.query(trainingQuery, [trainingDataJson], (err, result) => {
    if (err) {
      console.error('Error inserting training data:', err);
      return res.status(500).json({ error: 'Failed to insert training data' });
    }
    res.status(201).json({ message: 'Training data saved successfully', trainingId: result.insertId });
  });
});
module.exports = router;
