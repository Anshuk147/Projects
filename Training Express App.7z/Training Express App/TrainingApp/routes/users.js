var express = require('express');
var router = express.Router();
const connection = require('../public/javascripts/Database');
/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

// GET API to fetch all existing trainees
router.get("/trainees", (req, res) => {
  connection.query("SELECT * FROM existing_trainees", (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.status(200).json(results);
  });
});
//GET API to fetch the sops
router.get("/sop", async (req, res) => {
  try {
    const [rows] = await connection.promise().query("SELECT * FROM sop");
    res.status(200).json({ message: "SOP Details", data: rows });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
//GET API to fetch the trainer_details
router.get("/details",async(req,res)=>{
  try {
    const[rows]=await connection.promise().query("select * from trainer_details");
    res.status(200).json({ message: "trainer Details", data: rows });
  } catch (error) {
    res.status(400).json({ error: err.message });
  }
})
module.exports = router;
