const { exec } = require('child_process');
const path = require('path');

// Function to convert DOCX to PDF using full path to soffice
function convertDocxToPdf(inputPath, outputPath) {
  return new Promise((resolve, reject) => {
    const inputFilePath = path.resolve(inputPath);
    const outputDir = path.dirname(path.resolve(outputPath));

    // Construct the full path to soffice executable
    const sofficePath = 'C:\\Program Files\\LibreOffice\\program\\soffice.exe';

    // Construct the LibreOffice command
    const command = `"${sofficePath}" --headless --convert-to pdf --outdir "${outputDir}" "${inputFilePath}"`;

    // Execute the command
    exec(command, (error, stdout, stderr) => {
      if (error) {
        console.error(`Error converting DOCX to PDF: ${error}`);
        reject(error);
        return;
      }
      console.log(`Successfully converted DOCX to PDF: ${outputPath}`);
      resolve();
    });
  });
}

// Usage
const inputPath = './sample.docx';
const outputPath = './output.pdf';
convertDocxToPdf(inputPath, outputPath);
